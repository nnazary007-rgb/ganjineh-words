گنجینه واژه‌ها - پروژه اندروید

این پروژه یک پوسته اندرویدی WebView برای بازی HTML فعلی است.
برای ساخت APK:
1) Android Studio را نصب کنید.
2) این پوشه را در Android Studio باز کنید.
3) اجازه دهید Gradle Sync و دریافت Android SDK انجام شود.
4) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را انتخاب کنید.

مسیر APK خروجی معمولاً:
app/build/outputs/apk/debug/app-debug.apk

نکته: این پروژه هنوز نسخه انتشار نهایی و امضاشده فروشگاهی نیست.
شناسه برنامه فعلی: com.example.ganjineh
